Team Name: Team_TechMinaret
Institution Name: Shahjalal University of Science and Technology

List of Team Members:
1. ssh.rezvi@gmail.com
2. tamim11903060@gmail.com
3. muntasirnahid87@gmail.com


